import sqlite3
from config import config

class UserProfile:
    @staticmethod
    def create(name, email, contact):
        conn = sqlite3.connect(config.DATABASE_NAME)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (name, email, emergency_contact) VALUES (?, ?, ?)', 
                       (name, email, contact))
        conn.commit()
        conn.close()

    @staticmethod
    def get_by_email(email):
        conn = sqlite3.connect(config.DATABASE_NAME)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        conn.close()
        return user
