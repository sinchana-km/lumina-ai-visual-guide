from flask import Flask, render_template
from flask_socketio import SocketIO, emit
from flask_cors import CORS
import cv2
import base64
import numpy as np
from detection.detector import DetectionEngine
from ocr.reader import OCRReader
from voice.assistant import VoiceAssistant
from config import config

app = Flask(__name__)
app.config.from_object(config)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Initialize AI Engines
detector = DetectionEngine()
ocr = OCRReader()
voice = VoiceAssistant()

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('status', {'message': 'System Online'})

@socketio.on('process_frame')
def handle_frame(data):
    # Decode base64 image from frontend
    img_data = data['image'].split(',')[1]
    nparr = np.frombuffer(base64.b64decode(img_data), np.uint8)
    frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    task = data.get('task', 'general')
    response = {}

    if task == 'ocr':
        text = ocr.read_text(frame)
        response = {"text": text, "type": "OCR"}
    else:
        results = detector.process_frame(frame)
        response = {"detections": results, "type": "DETECTION"}
        
        # Auto-announce high confidence objects
        if results:
            announcement = f"I see a {results[0]['label']} {results[0]['position']}"
            emit('audio_feedback', {'text': announcement})

    emit('ai_response', response)

@socketio.on('voice_command')
def handle_voice(data):
    command = data['command'].lower()
    intent = voice.process_command(command)
    
    if intent == "WAKE_UP":
        emit('assistant_reply', {'text': "Hello. I am Lumina. What can I help you find?"})
    elif intent == "EMERGENCY":
        # logic for SOS
        emit('assistant_reply', {'text': "Initiating Emergency Protocol. Sharing location."})
        emit('emergency_alert', {'status': 'active'})

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
