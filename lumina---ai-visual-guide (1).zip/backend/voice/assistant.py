import speech_recognition as sr
import pyttsx3
import threading

class VoiceAssistant:
    def __init__(self):
        self.engine = pyttsx3.init()
        self.recognizer = sr.Recognizer()
        self.is_listening = False
        
        # Configure Voice
        voices = self.engine.getProperty('voices')
        self.engine.setProperty('voice', voices[0].id) # Usually English
        self.engine.setProperty('rate', 160)

    def speak(self, text):
        print(f"Assistant: {text}")
        # Run in thread to avoid blocking AI processing
        def run_speak():
            self.engine.say(text)
            self.engine.runAndWait()
        
        threading.Thread(target=run_speak).start()

    def listen(self):
        with sr.Microphone() as source:
            print("Listening...")
            self.recognizer.adjust_for_ambient_noise(source)
            try:
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=5)
                command = self.recognizer.recognize_google(audio)
                return command.lower()
            except sr.UnknownValueError:
                return ""
            except sr.RequestError:
                return "error"
            except Exception:
                return ""

    def process_command(self, command):
        # Basic intent mapping
        if "hello assistant" in command or "start" in command:
            return "WAKE_UP"
        if "detect" in command or "looking" in command:
            return "DESCRIBE_SCENE"
        if "read" in command or "sign" in command:
            return "READ_TEXT"
        if "emergency" in command or "help" in command:
            return "EMERGENCY"
        if "navigation" in command or "home" in command:
            return "NAVIGATE"
        return "UNKNOWN"
