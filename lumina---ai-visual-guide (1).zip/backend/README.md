# Lumina AI Backend - Visually Impaired Assistant

This is the Python-based AI engine for the Lumina assistant. It handles real-time computer vision, OCR, and voice processing.

## Prerequisites
- Python 3.9+
- Camera and Microphone access
- (Optional) CUDA-enabled GPU for faster YOLO performance

## Setup Instructions

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure Environment:**
   - Copy `.env.example` to `.env`
   - Add your `FIREBASE_CREDENTIALS` and `GOOGLE_MAPS_API_KEY`

4. **Run Application:**
   ```bash
   python app.py
   ```

## Modular Structure
- `app.py`: Flask-SocketIO server for real-time interaction.
- `/detection`: YOLOv8 based object and color detection.
- `/ocr`: EasyOCR integration for signboard reading.
- `/voice`: Speech-to-Text and Text-to-Speech logic.
- `/navigation`: Google Maps based routing guidance.
- `/emergency`: SOS triggers and location sharing.

## Voice Commands Supported
- "Hello Assistant" - Wake up call
- "Describe front" - Scene analysis
- "Read signs" - OCR activation
- "Emergency help" - SOS trigger
- "Navigate home" - Navigation support
