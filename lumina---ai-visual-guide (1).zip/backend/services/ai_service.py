from database.manager import DatabaseManager
from config import config

class AIService:
    def __init__(self):
        self.db = DatabaseManager()
        # Initialize any deep learning models here if not in detector
    
    def generate_summary(self, detections):
        if not detections:
            return "The path ahead looks clear."
            
        summary = "I see "
        items = [f"{d['label']} {d['position']}" for d in detections[:3]]
        summary += ", ".join(items)
        return summary
    
    def process_natural_language(self, text):
        # In production, call Gemini/OpenAI here
        # For now, keyword based or simple heuristic
        return f"I understood you said: {text}. How can I assist further?"
