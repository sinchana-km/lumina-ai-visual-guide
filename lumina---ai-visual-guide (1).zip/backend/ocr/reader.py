import easyocr
import cv2

class OCRReader:
    def __init__(self, languages=['en']):
        self.reader = easyocr.Reader(languages)

    def read_text(self, frame):
        # Pre-process for better OCR
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        # Thresholding or denoising can be added here
        
        results = self.reader.readtext(gray)
        text_lines = [res[1] for res in results]
        return " ".join(text_lines) if text_lines else "No text detected."

    def extract_signboard_info(self, frame):
        # Specific logic for finding sign-like patterns
        # For now, uses standard OCR but could be enhanced with detector
        return self.read_text(frame)
