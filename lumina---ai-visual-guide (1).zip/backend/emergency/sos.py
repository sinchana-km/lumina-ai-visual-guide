import requests
from config import config

class EmergencySystem:
    def __init__(self):
        self.contacts = [] # Load from Database

    def trigger_sos(self, location):
        """
        In production, this would use Twilio or a similar SMS gateway
        to send alerts to emergency contacts.
        """
        message = f"EMERGENCY: User requires assistance. Current Location: {location}"
        print(f"SOS TRIGGERED: {message}")
        # Simulation of API call
        return {"status": "sent", "contacts_notified": len(self.contacts)}

    def play_alarm(self):
        # Trigger loud sound on device
        pass
