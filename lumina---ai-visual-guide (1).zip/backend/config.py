import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev_secret")
    FIREBASE_CREDS = os.getenv("FIREBASE_CREDENTIALS_PATH")
    GOOGLE_MAPS_KEY = os.getenv("GOOGLE_MAPS_API_KEY")
    GEMINI_KEY = os.getenv("GEMINI_API_KEY")
    DATABASE_NAME = "lumina_assistant.db"

config = Config()
