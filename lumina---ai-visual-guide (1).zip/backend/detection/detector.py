import cv2
import numpy as np
from ultralytics import YOLO
import math

class DetectionEngine:
    def __init__(self, model_path='yolov8n.pt'):
        # Using nano model for real-time performance on low-end hardware
        self.model = YOLO(model_path)
        self.classes = self.model.names

    def process_frame(self, frame):
        results = self.model(frame, verbose=False)
        detections = []
        
        for r in results:
            boxes = r.boxes
            for box in boxes:
                # Get coordinates
                x1, y1, x2, y2 = box.xyxy[0]
                conf = math.ceil((box.conf[0] * 100)) / 100
                cls = int(box.cls[0])
                name = self.classes[cls]
                
                # Estimate distance based on box size (simplified)
                # In real app, we use camera focal length calibration
                w = x2 - x1
                h = y2 - y1
                area = w * h
                distance = "near" if area > 50000 else "far"
                
                # Determine position
                center_x = (x1 + x2) / 2
                frame_w = frame.shape[1]
                if center_x < frame_w / 3:
                    pos = "on your left"
                elif center_x > (frame_w / 3) * 2:
                    pos = "on your right"
                else:
                    pos = "straight ahead"

                detections.append({
                    "label": name,
                    "confidence": conf,
                    "position": pos,
                    "distance": distance,
                    "box": [int(x1), int(y1), int(x2), int(y2)]
                })
        
        return detections

    def get_color(self, frame, box):
        # Extract the object area
        x1, y1, x2, y2 = box
        roi = frame[y1:y2, x1:x2]
        if roi.size == 0: return "unknown"
        
        # Calculate mean color
        avg_color_per_row = np.average(roi, axis=0)
        avg_color = np.average(avg_color_per_row, axis=0)
        # BGR to simple name logic (Simplified)
        b, g, r = avg_color
        if r > 200 and g < 100: return "red"
        if g > 200 and r < 100: return "green"
        if b > 200 and r < 100: return "blue"
        if r > 200 and g > 200: return "yellow"
        if r < 50 and g < 50 and b < 50: return "black"
        if r > 200 and g > 200 and b > 200: return "white"
        
        return "neutral"
