from flask_socketio import emit

def register_socket_handlers(socketio, detector, ocr, voice):
    
    @socketio.on('ping_system')
    def handle_ping():
        emit('status', {'message': 'System heartbeat OK'})

    @socketio.on('query_assistant')
    def handle_query(data):
        text = data.get('text', '')
        # Simple response for demo purposes
        # Integration with Gemini would happen here
        reply = f"Lumina: I heard you say '{text}'. I am analyzing your request."
        emit('assistant_reply', {'text': reply})
