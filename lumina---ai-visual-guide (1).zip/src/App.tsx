import { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Navigation, 
  AlertTriangle, 
  Eye, 
  Type, 
  Sun,
  Moon,
  ChevronLeft,
  Wifi,
  WifiOff
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { speechEngine } from './lib/speech';
import { analyzeImage, VisionResult, chatWithAssistant } from './lib/gemini';
import { socket } from './lib/socket';

// Components
import Orb from './components/Orb';
import VoiceSubtitles from './components/VoiceSubtitles';
import RadarOverlay from './components/RadarOverlay';
import NavigationModule from './components/NavigationModule';

type ViewState = 'splash' | 'dashboard' | 'camera';
type AppTask = 'general' | 'ocr' | 'emergency';

const MAPS_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasMapsKey = Boolean(MAPS_KEY) && MAPS_KEY !== 'YOUR_API_KEY';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('splash');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [status, setStatus] = useState("");
  const [subtitleType, setSubtitleType] = useState<'user' | 'assistant' | 'status'>('status');
  const [lang, setLang] = useState<'en-US' | 'kn-IN'>('en-US');
  const [isNightMode, setIsNightMode] = useState(false);
  const [lastResult, setLastResult] = useState<VisionResult | null>(null);
  const [isContinuousMode, setIsContinuousMode] = useState(false);
  const [isSocketConnected, setIsSocketConnected] = useState(false);
  const [navDestination, setNavDestination] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const continuousInterval = useRef<NodeJS.Timeout | null>(null);

  // Helper: Speak and update UI
  const announce = (text: string, type: 'assistant' | 'status' = 'assistant') => {
    setStatus(text);
    setSubtitleType(type);
    speechEngine.speak(text, lang);
  };

  // --- VISION ENGINE ---
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: 640, height: 480 } 
      });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      announce("Camera error. Please ensure permissions are granted.");
    }
  };

  const captureAndAnalyze = useCallback(async (task: AppTask, silent: boolean = false) => {
    if (!videoRef.current || !canvasRef.current || isProcessing) return;

    if (!silent) {
       setIsProcessing(true);
       setStatus(task === 'ocr' ? "Scanning text..." : "Analyzing scene...");
       setSubtitleType('status');
    }

    try {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx && videoRef.current) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        
        // Advanced: Simulate Face Recognition/Context
        const detections = [];
        if (Math.random() > 0.7) {
           detections.push("Face (Identified as Family)");
        }

        if (isNightMode) {
           const id = ctx.getImageData(0,0,canvas.width,canvas.height);
           for(let i=0; i<id.data.length; i+=4) { 
             id.data[i] = Math.min(255, id.data[i] * 1.5); 
             id.data[i+1] = Math.min(255, id.data[i+1] * 1.5); 
             id.data[i+2] = Math.min(255, id.data[i+2] * 1.5); 
           }
           ctx.putImageData(id, 0, 0);
        }
        const b64 = canvas.toDataURL('image/jpeg', 0.8).split(',')[1];
        const result = await analyzeImage(b64, task, lang);
        setLastResult(result);
        
        let output = result.sceneDescription;

        // Structured obstacle warnings
        if (result.detections && result.detections.length > 0) {
          // Sort by urgency first (high -> medium -> low), then by distance
          const sortedDetections = [...result.detections].sort((a, b) => {
            const urgencyMap = { high: 0, medium: 1, low: 2 };
            if (urgencyMap[a.urgency] !== urgencyMap[b.urgency]) {
              return urgencyMap[a.urgency] - urgencyMap[b.urgency];
            }
            return a.distance - b.distance;
          });

          const urgentObstacles = sortedDetections.filter(d => d.urgency === 'high' || d.distance <= 1.5);
          
          if (urgentObstacles.length > 0) {
            const warnings = urgentObstacles.map((d, idx) => {
              // Only announce top 2 most urgent to avoid overwhelming the user
              if (idx > 1) return null;
              
              const label = d.label;
              const pos = lang === 'kn-IN' 
                ? (d.position === 'left' ? 'ಎಡಕ್ಕೆ' : d.position === 'right' ? 'ಬಲಕ್ಕೆ' : 'ನೇರವಾಗಿ ಮುಂದೆ') 
                : (d.position === 'center' ? 'straight ahead' : `on the ${d.position}`);
              
              const dist = d.distance < 1 ? (lang === 'kn-IN' ? 'ಒಂದು ಮೀಟರ್‌ಗಿಂತ ಕಡಿಮೆ' : 'less than one meter') : `${d.distance.toFixed(1)} ${lang === 'kn-IN' ? 'ಮೀಟರ್' : 'meters'}`;
              
              return lang === 'kn-IN' 
                ? `${label} ${pos} ${dist} ದೂರದಲ್ಲಿದೆ`
                : `${label}, ${pos}, at ${dist}`;
            }).filter(Boolean);

            if (warnings.length > 0) {
              const prefix = lang === 'kn-IN' ? 'ಎಚ್ಚರಿಕೆ:' : 'Careful:';
              output = `${prefix} ${warnings.join('. ')}. ${output}`;
            }
          }
        }

        if (task === 'ocr' && result.signText) output = `I read: ${result.signText}`;
        if (task === 'emergency' && result.hazardLevel !== 'low') output = `Warning: ${result.hazardLevel} hazard. ${result.suggestedAction || ''}`;
        
        announce(output);
      }
    } catch (e) {
      if (!silent) announce("Vision analysis failed. Please try again.");
    } finally {
      if (!silent) setIsProcessing(false);
    }
  }, [lang, isNightMode, isProcessing]);

  // --- VOICE COMMAND HANDLER ---
  const handleCommand = useCallback(async (transcript: string) => {
    console.log("CMD:", transcript);
    setStatus(transcript);
    setSubtitleType('user');
    
    if (transcript.includes("hello assistant") || transcript.includes("hi assistant")) {
       announce("I am listening. How can I help?");
       return;
    }

    if (transcript.includes("kannada") || transcript.includes("ಕನ್ನಡ")) {
      setLang('kn-IN');
      announce("ಕನ್ನಡ ಭಾಷೆ ಸಕ್ರಿಯಗೊಳಿಸಲಾಗಿದೆ.", 'assistant');
      return;
    }

    if (transcript.includes("english")) {
      setLang('en-US');
      announce("English language enabled.");
      return;
    }

    if (transcript.includes("read") || transcript.includes("text") || transcript.includes("ocr")) {
      setCurrentView('camera');
      announce("Switching to scan mode.", 'status');
      setTimeout(() => captureAndAnalyze('ocr'), 1500);
      return;
    }

    if (transcript.includes("describe") || transcript.includes("look") || transcript.includes("front") || transcript.includes("where") || transcript.includes("see")) {
      setCurrentView('camera');
      announce("Scanning environment.", 'status');
      setTimeout(() => captureAndAnalyze('general'), 1500);
      return;
    }

    if (transcript.includes("emergency") || transcript.includes("help") || transcript.includes("danger") || transcript.includes("unsafe")) {
      announce("Emergency mode active. Scanning for immediate hazards.");
      setCurrentView('camera');
      setTimeout(() => captureAndAnalyze('emergency'), 1500);
      return;
    }

    if (transcript.includes("night") || transcript.includes("dark")) {
      setIsNightMode(true);
      announce("Night vision optics engaged.");
      return;
    }

    if (transcript.includes("continuous") || transcript.includes("every few seconds") || transcript.includes("loop")) {
      setIsContinuousMode(true);
      announce("Continuous monitoring enabled. I will update you automatically.");
      return;
    }

    if (transcript.includes("stop") || transcript.includes("quiet") || transcript.includes("enough")) {
      setIsContinuousMode(false);
      setNavDestination(null);
      announce("Stopped all active tasks.");
      return;
    }

    if (transcript.includes("navigate to") || transcript.includes("go to") || transcript.includes("directions to")) {
      const dest = transcript.split(/navigate to|go to|directions to/i)[1]?.trim();
      if (dest) {
        setNavDestination(dest);
        announce(`Searching for directions to ${dest}.`);
        setCurrentView('camera'); // Switch to camera to see obstacles
      } else {
        announce("Where would you like to go?");
      }
      return;
    }

    if (transcript.includes("talk faster") || transcript.includes("speak faster") || transcript.includes("increase speed")) {
      speechEngine.setRate(1.5);
      announce("I will speak faster now.");
      return;
    }

    if (transcript.includes("talk slower") || transcript.includes("speak slower") || transcript.includes("decrease speed")) {
      speechEngine.setRate(0.7);
      announce("I will speak more slowly.");
      return;
    }

    if (transcript.includes("normal speed") || transcript.includes("default speed")) {
      speechEngine.setRate(1.0);
      announce("Returning to normal speech rate.");
      return;
    }

    if (transcript.includes("dashboard") || transcript.includes("home") || transcript.includes("back")) {
      setCurrentView('dashboard');
      announce("Returning to dashboard.");
      return;
    }

    // Default: AI Chat
    setIsProcessing(true);
    let b64: string | undefined = undefined;
    
    // If in camera view or command suggests vision, try to capture frame
    if (currentView === 'camera' || transcript.includes("what") || transcript.includes("this") || transcript.includes("who")) {
       if (videoRef.current && canvasRef.current) {
          const canvas = canvasRef.current;
          const ctx = canvas.getContext('2d');
          if (ctx) {
             ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
             b64 = canvas.toDataURL('image/jpeg', 0.6).split(',')[1];
          }
       }
    }

    const reply = await chatWithAssistant(transcript, b64, lang);
    announce(reply);
    setIsProcessing(false);

  }, [captureAndAnalyze, lang, currentView]);

  // --- LIFECYCLE ---
  useEffect(() => {
    const onConnect = () => setIsSocketConnected(true);
    const onDisconnect = () => setIsSocketConnected(false);
    
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    
    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, []);
  useEffect(() => {
    speechEngine.setLanguage(lang);
    speechEngine.setCallbacks(
      () => setIsSpeaking(true),
      () => setIsSpeaking(false)
    );
  }, [lang]);

  // Continuous monitoring loop
  useEffect(() => {
    if (isContinuousMode && currentView === 'camera') {
      continuousInterval.current = setInterval(() => {
        captureAndAnalyze('general', true);
      }, 5000); 
    } else if (continuousInterval.current) {
      clearInterval(continuousInterval.current);
    }
    return () => {
      if (continuousInterval.current) clearInterval(continuousInterval.current);
    };
  }, [isContinuousMode, currentView, captureAndAnalyze]);

  useEffect(() => {
    if (currentView === 'splash' && hasMapsKey) {
       const timer = setTimeout(() => {
         setCurrentView('dashboard');
         speechEngine.startListening(
           handleCommand,
           (err) => {
             if (err === 'network') {
               setStatus("Connection loss. Retrying...");
               setSubtitleType('status');
             } else if (err === 'not-allowed') {
               setStatus("Microphone access denied.");
               setSubtitleType('status');
             }
           }
         );
         setIsListening(true);
         announce("Lumina system online. Say Hello Assistant to begin.");
       }, 3000);
       return () => clearTimeout(timer);
    }
    
    if (currentView === 'camera') {
      startCamera();
    }
  }, [currentView, handleCommand]);

  // --- VIEW RENDERING ---
  const renderSplash = () => (
    <motion.div 
      key="splash"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-screen bg-black p-8"
    >
      {!hasMapsKey ? (
        <div className="text-center max-w-md space-y-6">
          <div className="w-20 h-20 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto border border-amber-500/30">
            <AlertTriangle className="text-amber-500" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-white">Maps API Key Required</h2>
          <p className="text-gray-400 text-sm leading-relaxed">
            To enable navigation features, please add your Google Maps Platform key to the project secrets.
          </p>
          <div className="bg-white/5 rounded-xl p-4 text-left border border-white/10 space-y-3 font-mono text-[10px]">
            <p><span className="text-neon-cyan">1.</span> Visit Google Cloud Console</p>
            <p><span className="text-neon-cyan">2.</span> Open Settings (⚙️ icon) → Secrets</p>
            <p><span className="text-neon-cyan">3.</span> Add <code className="bg-white/10 px-1 rounded">GOOGLE_MAPS_PLATFORM_KEY</code></p>
          </div>
          <p className="text-[9px] text-gray-500 uppercase tracking-widest">App will rebuild automatically</p>
        </div>
      ) : (
        <>
          <motion.div
            animate={{ scale: [0.9, 1.1, 0.9], opacity: [0.5, 1, 0.5] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-32 h-32 bg-neon-cyan/20 rounded-full shadow-[0_0_80px_rgba(0,243,255,0.4)] flex items-center justify-center mb-8 border border-neon-cyan/30"
          >
            <Eye size={48} className="text-neon-cyan glow-cyan" />
          </motion.div>
          <h1 className="text-5xl font-bold tracking-tighter glow-text-cyan flex gap-1">
            LUMINA<span className="text-xs font-mono self-start mt-2">V1.0</span>
          </h1>
          <p className="text-gray-500 mt-4 font-mono text-[10px] uppercase tracking-widest animate-pulse">Synchronizing Neural Core...</p>
        </>
      )}
    </motion.div>
  );

  const renderDashboard = () => (
    <motion.div 
      key="dashboard"
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center h-screen p-8 bg-[radial-gradient(circle_at_center,rgba(0,102,255,0.05)_0%,transparent_70%)]"
    >
      <div className="absolute top-10 left-10 flex gap-4">
        <div className={`px-3 py-1 rounded-full border border-white/10 text-[10px] font-mono uppercase tracking-tighter ${lang === 'kn-IN' ? 'bg-neon-purple/20 text-neon-purple border-neon-purple/30' : 'bg-neon-cyan/20 text-neon-cyan border-neon-cyan/30'}`}>
          {lang === 'kn-IN' ? 'Kannada Mode' : 'English Mode'} 
        </div>
        <div className={`px-3 py-1 rounded-full border border-white/10 text-[10px] font-mono uppercase tracking-tighter ${isListening ? 'bg-red-500/20 text-red-500 border-red-500/30' : 'bg-gray-800 text-gray-500'}`}>
          Audio: {isListening ? 'Streaming' : 'Idle'}
        </div>
        <div className={`px-3 py-1 rounded-full border border-white/10 text-[10px] font-mono uppercase tracking-tighter ${isSocketConnected ? 'bg-green-500/20 text-green-500 border-green-500/30' : 'bg-amber-500/20 text-amber-500 border-amber-500/30'}`}>
          {isSocketConnected ? <Wifi size={12} className="inline mr-1" /> : <WifiOff size={12} className="inline mr-1" />}
          Net: {isSocketConnected ? 'Sync' : 'Offline'}
        </div>
      </div>

      <Orb isListening={isListening} isProcessing={isProcessing} isSpeaking={isSpeaking} />
      
      <div className="mt-24 space-y-6 text-center max-w-sm">
        <div className="space-y-1">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className={`w-1.5 h-1.5 rounded-full ${isListening ? 'bg-red-500 animate-pulse' : 'bg-gray-700'}`} />
            <h2 className="text-[10px] font-mono text-gray-400 uppercase tracking-[0.2em]">{isListening ? 'Aura Active' : 'Neural Standby'}</h2>
          </div>
          <p className="text-2xl font-light text-white tracking-tight">
            {isProcessing ? 'Analyzing...' : isSpeaking ? 'Communicating' : 'Listening...'}
          </p>
        </div>
        <div className="p-4 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10">
          <p className="text-xs text-gray-400 italic font-mono leading-relaxed">
            "Say: 'Describe my front' to start navigation support"
          </p>
        </div>
      </div>

      {/* Manual Quick-Access */}
      <div className="fixed bottom-12 left-1/2 -translate-x-1/2 flex gap-4 md:gap-6 bg-black/40 backdrop-blur-xl p-4 rounded-3xl border border-white/10 shadow-2xl">
         <button id="tap-scan" onClick={() => handleCommand("describe")} className="w-16 h-16 rounded-2xl bg-neon-cyan/10 border border-neon-cyan/20 flex flex-col items-center justify-center text-neon-cyan hover:bg-neon-cyan/20 transition-all">
           <Eye size={20} />
           <span className="text-[8px] font-bold mt-1 uppercase">Scan</span>
         </button>
         <button id="tap-read" onClick={() => handleCommand("read")} className="w-16 h-16 rounded-2xl bg-neon-blue/10 border border-neon-blue/20 flex flex-col items-center justify-center text-neon-blue hover:bg-neon-blue/20 transition-all">
           <Type size={20} />
           <span className="text-[8px] font-bold mt-1 uppercase">Read</span>
         </button>
         <button id="tap-sos" onClick={() => handleCommand("emergency")} className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex flex-col items-center justify-center text-red-500 hover:bg-red-500/20 transition-all">
           <AlertTriangle size={20} className="animate-pulse" />
           <span className="text-[8px] font-bold mt-1 uppercase">SOS</span>
         </button>
      </div>
    </motion.div>
  );

  const renderCamera = () => (
    <motion.div 
      key="camera"
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative h-screen bg-black"
    >
      <video ref={videoRef} autoPlay playsInline muted className={`w-full h-full object-cover grayscale-[0.3] transition-all duration-700 ${isNightMode ? 'brightness-150 contrast-125 sepia-[0.3]' : ''}`} />
      <canvas ref={canvasRef} width="640" height="480" className="hidden" />
      
      {/* Scanline and HUD */}
      <div className="absolute inset-0 scanline" />
      <RadarOverlay />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)]" />

      {/* Header Info */}
      <div className="absolute top-8 left-8 right-8 flex justify-between items-start z-50">
        <button 
          onClick={() => setCurrentView('dashboard')}
          className="p-3 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10 text-white flex items-center gap-2 hover:bg-white/10"
        >
          <ChevronLeft size={20} /> <span className="text-[10px] uppercase font-bold tracking-widest pr-2">Return</span>
        </button>
        <div className="flex flex-col items-end gap-2">
           <div className="px-3 py-1 bg-red-500 text-white text-[8px] font-mono font-bold uppercase rounded animate-pulse">Live Feed</div>
           <div className="font-mono text-[10px] text-neon-cyan opacity-80">LAT: 12.9716 / LON: 77.5946</div>
        </div>
      </div>

      {/* Control Tools */}
      <div className="absolute bottom-12 right-8 flex flex-col gap-4 z-50">
        <button onClick={() => setIsNightMode(!isNightMode)} className={`p-4 rounded-2xl border transition-all ${isNightMode ? 'bg-amber-500 border-amber-600 text-black shadow-[0_0_20px_rgba(245,158,11,0.4)]' : 'bg-black/40 backdrop-blur-xl border-white/10 text-white'}`}>
           {isNightMode ? <Sun /> : <Moon />}
        </button>
      </div>

      {/* AI Intelligence HUD */}
      <AnimatePresence>
        {lastResult && (
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            className="absolute left-8 bottom-32 w-64 p-4 bg-black/60 backdrop-blur-2xl border-l-2 border-neon-cyan rounded-r-2xl z-50 pointer-events-none"
          >
             <h3 className="text-[10px] font-mono text-neon-cyan uppercase tracking-widest mb-3">AI Intelligence Output</h3>
             <div className="space-y-3">
               <div>
                  <p className="text-[8px] text-gray-400 uppercase mb-1">Obstacles Detected</p>
                  <div className="space-y-2">
                    {lastResult.detections?.map((d, i) => (
                      <div key={i} className="flex items-center justify-between bg-white/5 p-2 rounded border border-white/5">
                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-white uppercase">{d.label}</span>
                          <span className="text-[8px] text-gray-500 uppercase">{d.position}</span>
                        </div>
                        <div className="flex flex-col items-end">
                          <span className="text-[10px] font-mono text-neon-cyan">{d.distance.toFixed(1)}m</span>
                          <span className={`text-[7px] font-bold uppercase ${d.urgency === 'high' ? 'text-red-500' : d.urgency === 'medium' ? 'text-amber-500' : 'text-green-500'}`}>
                            {d.urgency}
                          </span>
                        </div>
                      </div>
                    ))}
                    {(!lastResult.detections || lastResult.detections.length === 0) && (
                      <div className="flex flex-wrap gap-1">
                        {lastResult.objects.map((o,i) => (
                          <span key={i} className="text-[9px] bg-white/10 px-2 py-0.5 rounded-full border border-white/5">{o}</span>
                        ))}
                      </div>
                    )}
                  </div>
               </div>
               <div>
                  <p className="text-[8px] text-gray-400 uppercase mb-1">Hazard Assessment</p>
                  <p className={`text-xs font-bold uppercase ${lastResult.hazardLevel === 'high' ? 'text-red-500' : lastResult.hazardLevel === 'medium' ? 'text-amber-500' : 'text-green-500'}`}>
                    {lastResult.hazardLevel} RISK
                  </p>
               </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {navDestination && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="z-50"
          >
            <NavigationModule 
              destination={navDestination} 
              lang={lang}
              hazardLevel={lastResult?.hazardLevel}
              onStepChange={(step) => announce(step)}
              onArrival={() => {
                announce("You have arrived at your destination.");
                setNavDestination(null);
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );

  return (
    <div className="font-sans min-h-screen bg-[#030303] text-white selection:bg-neon-cyan/30">
      <AnimatePresence mode="wait">
        {currentView === 'splash' ? renderSplash() : 
         currentView === 'dashboard' ? renderDashboard() : 
         renderCamera()}
      </AnimatePresence>

      <VoiceSubtitles text={status} type={subtitleType} />
      
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-[-1] bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
    </div>
  );
}
