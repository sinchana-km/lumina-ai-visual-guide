import { motion, AnimatePresence } from 'motion/react';

interface VoiceSubtitlesProps {
  text: string;
  type: 'user' | 'assistant' | 'status';
}

export default function VoiceSubtitles({ text, type }: VoiceSubtitlesProps) {
  if (!text) return null;

  return (
    <div className="fixed bottom-32 left-0 right-0 z-50 flex justify-center px-8 pointer-events-none">
      <AnimatePresence mode="wait">
        <motion.div
          key={text}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className={`px-6 py-3 rounded-2xl backdrop-blur-xl border border-white/10 text-center max-w-2xl
            ${type === 'user' ? 'bg-neon-blue/20 text-neon-cyan text-sm italic' : 
              type === 'assistant' ? 'bg-white/10 text-white text-xl md:text-2xl font-medium' : 
              'bg-gray-800/40 text-gray-400 text-xs uppercase letter-tracking-widest'}
          `}
        >
          {text}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
