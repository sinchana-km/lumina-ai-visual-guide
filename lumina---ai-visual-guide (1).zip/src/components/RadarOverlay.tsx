import { motion } from 'motion/react';

export default function RadarOverlay() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {/* Circular Radar Scan */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] 
          bg-gradient-conic from-neon-cyan/20 via-transparent to-transparent opacity-30"
      />
      
      {/* Target Crosshairs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border border-white/10 rounded-full flex items-center justify-center">
         <div className="w-1 h-8 bg-neon-cyan/30 absolute" />
         <div className="h-1 w-8 bg-neon-cyan/30 absolute" />
      </div>

      {/* Grid Lines */}
      <div className="absolute inset-0 opacity-10 bg-[linear-gradient(rgba(0,243,255,0.2)_1px,transparent_1px),linear-gradient(90deg,rgba(0,243,255,0.2)_1px,transparent_1px)] bg-[size:40px_40px]" />
      
      {/* Floating Data Points */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.5, 0], x: Math.random() * 200 - 100, y: Math.random() * 200 - 100 }}
          transition={{ repeat: Infinity, duration: 3 + i, delay: i }}
          className="absolute top-1/2 left-1/2 w-1 h-1 bg-neon-cyan rounded-full shadow-[0_0_5px_cyan]"
        />
      ))}
    </div>
  );
}
