import { motion } from 'motion/react';

interface OrbProps {
  isListening: boolean;
  isProcessing: boolean;
  isSpeaking?: boolean;
  intensity?: number;
}

export default function Orb({ isListening, isProcessing, isSpeaking, intensity = 1 }: OrbProps) {
  return (
    <div className="relative w-48 h-48 md:w-64 md:h-64 flex items-center justify-center">
      {/* Outer Glow */}
      <motion.div
        animate={{
          scale: isListening || isSpeaking ? [1, 1.2, 1] : 1,
          opacity: isListening ? [0.3, 0.6, 0.3] : isSpeaking ? [0.4, 0.8, 0.4] : 0.2,
          backgroundColor: isSpeaking ? "rgba(168, 85, 247, 0.2)" : "rgba(0, 243, 255, 0.2)"
        }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute inset-0 rounded-full blur-3xl transition-colors duration-500"
      />

      {/* Core Rings */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        className={`absolute inset-0 border-2 border-dashed rounded-full transition-colors duration-500 ${isSpeaking ? 'border-neon-purple/40' : 'border-neon-cyan/30'}`}
      />
      
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute inset-4 border border-white/5 rounded-full"
      />

      {/* Center Sphere */}
      <motion.div
        animate={isProcessing ? {
          scale: [1, 1.1, 1],
          filter: ["brightness(1)", "brightness(1.5)", "brightness(1)"],
        } : isListening || isSpeaking ? {
          scale: [0.95, 1.05, 0.95],
        } : {}}
        transition={{ repeat: Infinity, duration: 1.5 }}
        className={`relative z-10 w-24 h-24 md:w-32 md:h-32 rounded-full bg-gradient-radial shadow-2xl flex items-center justify-center overflow-hidden transition-all duration-500 ${
          isSpeaking 
          ? 'from-neon-purple via-purple-600/80 to-transparent shadow-neon-purple/50' 
          : 'from-neon-cyan via-neon-blue to-transparent shadow-[0_0_50px_rgba(0,243,255,0.6)]'
        }`}
      >
        {/* Internal Pulse */}
        <motion.div 
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ repeat: Infinity, duration: 3 }}
          className="w-full h-full bg-white opacity-20 blur-sm"
        />
      </motion.div>
      
      {/* Waveform Visualization */}
      <div className="absolute -bottom-12 flex gap-1.5 h-16 items-center">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            animate={isListening || isSpeaking ? {
              height: [4, (isSpeaking ? 30 : 20) + Math.random() * (isSpeaking ? 40 : 20), 4],
              backgroundColor: isSpeaking ? "#a855f7" : "#00f3ff",
              boxShadow: isSpeaking ? "0 0 12px rgba(168, 85, 247, 0.8)" : "0 0 12px rgba(0, 243, 255, 0.8)"
            } : { height: 4, backgroundColor: "rgba(255,255,255,0.1)", boxShadow: "none" }}
            transition={{ repeat: Infinity, duration: 0.3 + Math.random() * 0.4 }}
            className="w-1 rounded-full transition-all duration-300"
          />
        ))}
      </div>
    </div>
  );
}
