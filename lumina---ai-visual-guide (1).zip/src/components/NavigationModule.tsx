import { useEffect, useState, useRef } from 'react';
import { APIProvider, Map, useMap, useMapsLibrary, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';

interface NavigationModuleProps {
  destination: string | null;
  onArrival: () => void;
  onStepChange: (step: string) => void;
  lang: string;
  hazardLevel?: 'low' | 'medium' | 'high';
}

export default function NavigationModule({ destination, onArrival, onStepChange, lang, hazardLevel }: NavigationModuleProps) {
  const [userLocation, setUserLocation] = useState<google.maps.LatLngLiteral | null>(null);

  useEffect(() => {
    if (hazardLevel === 'high' && destination) {
       onStepChange(lang === 'kn-IN' ? "ಎಚ್ಚರಿಕೆ! ಮುಂದೆ ಅಡಚಣೆ ಇದೆ." : "Warning! Significant obstacle detected ahead. Please proceed with caution.");
    }
  }, [hazardLevel, destination, lang, onStepChange]);

  useEffect(() => {
    if (!navigator.geolocation) return;
    
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setUserLocation({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude
        });
      },
      (err) => console.error("Geolocation error:", err),
      { enableHighAccuracy: true }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  if (!API_KEY || !destination) return null;

  return (
    <APIProvider apiKey={API_KEY} version="weekly">
      <div className="absolute top-4 right-4 w-40 h-40 md:w-64 md:h-64 z-40 rounded-2xl overflow-hidden border-2 border-white/20 shadow-2xl backdrop-blur-md">
        <Map
          defaultCenter={{ lat: 12.9716, lng: 77.5946 }}
          defaultZoom={17}
          mapId="NAV_MAP"
          center={userLocation}
          disableDefaultUI={true}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          style={{ width: '100%', height: '100%' }}
        />
        {userLocation && (
          <AdvancedMarker position={userLocation}>
            <Pin background={'#00f3ff'} glyphColor={'#000'} borderColor={'#fff'} />
          </AdvancedMarker>
        )}
        {userLocation && destination && (
          <RouteLogic 
            origin={userLocation} 
            destination={destination} 
            onStepChange={onStepChange}
            onArrival={onArrival}
            lang={lang}
          />
        )}
        <div className="absolute top-2 left-2 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg border border-white/10">
          <p className="text-[8px] font-mono font-bold text-white uppercase tracking-widest">Tactical Map</p>
        </div>
      </div>
    </APIProvider>
  );
}

function RouteLogic({ origin, destination, onStepChange, onArrival, lang }: any) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);
  const lastStepIndex = useRef<number>(-1);

  useEffect(() => {
    if (!routesLib || !map || !origin || !destination) return;

    // Clear previous
    polylinesRef.current.forEach(p => p.setMap(null));

    routesLib.Route.computeRoutes({
      origin,
      destination,
      travelMode: 'WALKING',
      fields: ['path', 'legs.steps', 'legs.distanceMeters', 'legs.durationMillis'],
    }).then(({ routes }) => {
      if (routes?.[0]) {
        const route = routes[0];
        const newPolylines = route.createPolylines();
        newPolylines.forEach(p => p.setMap(map));
        polylinesRef.current = newPolylines;

        const leg = route.legs?.[0];
        if (leg && leg.steps && leg.steps.length > 0) {
           const nextStep = leg.steps[0];
           const distance = leg.distanceMeters || 0;
           
           let prompt = nextStep.instructions || "";
           if (distance > 20) {
             prompt = `${prompt}. Around ${Math.round(distance)} meters remaining.`;
           }

           if (lastStepIndex.current !== 0 || Math.abs((polylinesRef.current as any)._lastDist || 0 - distance) > 50) {
             onStepChange(prompt);
             lastStepIndex.current = 0;
             (polylinesRef.current as any)._lastDist = distance;
           }

           // If very close to destination
           if (distance < 10) {
             onArrival();
           }
        }
      }
    }).catch(err => console.error("Routing error:", err));

    return () => polylinesRef.current.forEach(p => p.setMap(null));
  }, [routesLib, map, origin, destination, onStepChange, onArrival]);

  return null;
}
