/**
 * Wrapper for Web Speech API (Recognition and Synthesis)
 */

export class SpeechEngine {
  private recognition: any;
  private synthesis: SpeechSynthesis;
  private isListening: boolean = false;
  private speechRate: number = 1.0;
  private onSpeakStart?: () => void;
  private onSpeakEnd?: () => void;

  constructor() {
    this.synthesis = window.speechSynthesis;
    
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.lang = 'en-US';
      this.recognition.interimResults = false;
    }
  }

  public setRate(rate: number): void {
    this.speechRate = Math.max(0.5, Math.min(2.0, rate));
  }

  public setCallbacks(onStart: () => void, onEnd: () => void): void {
    this.onSpeakStart = onStart;
    this.onSpeakEnd = onEnd;
  }

  public speak(text: string, lang: string = 'en-US'): Promise<void> {
    return new Promise((resolve) => {
      // Cancel any ongoing speech
      this.synthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = this.speechRate;
      utterance.pitch = 1.0;
      
      utterance.onstart = () => {
        if (this.onSpeakStart) this.onSpeakStart();
      };
      
      utterance.onend = () => {
        if (this.onSpeakEnd) this.onSpeakEnd();
        resolve();
      };

      utterance.onerror = () => {
        if (this.onSpeakEnd) this.onSpeakEnd();
        resolve();
      };

      this.synthesis.speak(utterance);
    });
  }

  public setLanguage(lang: string): void {
    if (this.recognition) {
      this.recognition.lang = lang;
      // If currently listening, we need to restart to apply the language change
      if (this.isListening) {
        this.recognition.stop();
        // The onend handler will automatically restart it with the new language
      }
    }
  }

  public startListening(onResult: (transcript: string) => void, onError?: (error: string) => void): void {
    if (!this.recognition || this.isListening) return;

    this.recognition.onresult = (event: any) => {
      const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
      onResult(transcript);
    };

    this.recognition.onerror = (event: any) => {
      const isRetryable = ['no-speech', 'audio-capture', 'network', 'aborted'].includes(event.error);
      
      // Don't log aborted, no-speech or network (since we handle it) as they are normal lifecycle events
      if (!['no-speech', 'aborted', 'network'].includes(event.error)) {
        console.error('Speech recognition error', event.error);
      }
      
      if (onError && !['no-speech', 'aborted'].includes(event.error)) {
        onError(event.error);
      }
      
      // Store the last error and increment retry count for network issues
      const lastError = (this.recognition as any)._lastError;
      const retryCount = (this.recognition as any)._retryCount || 0;
      
      (this.recognition as any)._lastError = event.error;
      if (event.error === 'network') {
        (this.recognition as any)._retryCount = retryCount + 1;
      } else {
        (this.recognition as any)._retryCount = 0;
      }

      if (isRetryable) {
        return; 
      }
      this.stopListening();
    };

    this.recognition.onend = () => {
      if (this.isListening) {
        const lastError = (this.recognition as any)._lastError;
        const retryCount = (this.recognition as any)._retryCount || 0;
        
        // Exponential backoff for network errors: 1s, 2s, 4s, 8s, max 10s
        let delay = 300;
        if (lastError === 'network') {
          delay = Math.min(10000, 1000 * Math.pow(2, Math.max(0, retryCount - 1)));
        } else if (lastError === 'no-speech') {
          delay = 100; // Fast restart for silence
        }
        
        setTimeout(() => {
          try {
            if (this.isListening) {
              this.recognition.start();
              // We don't reset _lastError here because we want to know it in next end if it fails again
            }
          } catch (e) {
            // Already started or busy
          }
        }, delay);
      }
    };

    try {
      this.recognition.start();
      this.isListening = true;
    } catch (e) {
      console.error("Failed to start recognition:", e);
    }
  }

  public stopListening(): void {
    this.isListening = false;
    if (this.recognition) {
      this.recognition.stop();
    }
  }
}

export const speechEngine = new SpeechEngine();
