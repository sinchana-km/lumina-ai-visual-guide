import { GoogleGenAI } from "@google/genai";

export type Detection = {
  label: string;
  distance: number; // estimated meters
  position: 'left' | 'center' | 'right';
  urgency: 'low' | 'medium' | 'high';
};

export type VisionResult = {
  objects: string[];
  colors: string[];
  sceneDescription: string;
  signText: string;
  hazardLevel: 'low' | 'medium' | 'high';
  suggestedAction?: string;
  detections?: Detection[];
};

// Initialize the Gemini API client directly on the frontend
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

// Local history for the session
const conversationHistory: any[] = [];

export async function chatWithAssistant(userInput: string, base64Image?: string, lang: string = 'en-US'): Promise<string> {
  try {
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: `
          You are Lumina, a friendly, calm, and supportive AI companion for a visually impaired person.
          Your personality is empathetic and safety-focused.
          Give short, helpful, and natural spoken-style replies.
          If context includes image data, describe it naturally for a blind user.
          Always reply in the specified language: ${lang}.
          If the language is kn-IN, use Kannada script.
          Keep responses under 30 words unless detail is requested.
        `
      },
      history: conversationHistory.slice(-10)
    });

    const parts: any[] = [{ text: userInput }];
    if (base64Image) {
      parts.push({ 
        inlineData: { 
          mimeType: "image/jpeg", 
          data: base64Image 
        } 
      });
    }

    const result = await chat.sendMessage({ message: parts });
    const responseText = result.text || "";

    // Update history
    conversationHistory.push({ role: 'user', parts: [{ text: userInput }] });
    conversationHistory.push({ role: 'model', parts: [{ text: responseText }] });

    return responseText;
  } catch (error) {
    console.error("Chat Error:", error);
    return lang === 'kn-IN' ? "ಕ್ಷಮಿಸಿ, ಸಂಪರ್ಕದ ತೊಂದರೆ ಇದೆ." : "I'm having trouble connecting right now.";
  }
}

export async function analyzeImage(base64Image: string, task: 'general' | 'ocr' | 'emergency' = 'general', lang: string = 'en-US'): Promise<VisionResult> {
  try {
    const prompt = task === 'ocr' 
      ? "Read everything on any signboards or documents in this image."
      : task === 'emergency'
      ? "Identify immediate dangers or hazards."
      : "Describe the objects and general scene.";

    const result = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Image } },
          { text: prompt }
        ]
      },
      config: { 
        systemInstruction: `
          You are an AI assistant for a visually impaired person. 
          Analyze the provided camera frame and provide a concise, helpful summary.
          Identify objects, colors, signboards, and hazards.

          EXTREMELY IMPORTANT: You are a spatial awareness system for a blind person.
          Identify and track specific obstacles: 'person', 'car', 'chair', 'stairs', 'door', 'wall', or 'pothole'.
          For each significant obstacle in the path:
          - label: Name of the object (e.g., "Parked Car", "Approaching Person").
          - distance: Estimated distance in meters (be as precise as possible, e.g., 0.8, 3.5).
          - position: 'left', 'center', or 'right' based on the frame.
          - urgency: 
            * 'high': Within 1.5m or directly in collision path.
            * 'medium': 1.5m to 4m away.
            * 'low': Beyond 4m or peripherally located.

          IMPORTANT: Provide text descriptions in: ${lang}.
          If lang is kn-IN, use Kannada script for labels and descriptions.
          Return a JSON object with:
          - objects: string[]
          - colors: string[]
          - sceneDescription: string
          - signText: string
          - hazardLevel: "low" | "medium" | "high" 
          - suggestedAction: string
          - detections: Array<{label: string, distance: number, position: "left"|"center"|"right", urgency: "low"|"medium"|"high"}>
        `,
        responseMimeType: "application/json" 
      }
    });

    const text = result.text || "{}";
    return JSON.parse(text);
  } catch (error) {
    console.error("Analysis Error:", error);
    return {
      objects: [],
      colors: [],
      sceneDescription: "Unable to analyze scene at this moment.",
      signText: "",
      hazardLevel: 'low'
    };
  }
}
