# Lumina - AI Visual Guide

An AI-powered smart assistant designed for visually impaired users. Operates fully via voice commands and provides real-time scene description using Gemini 3.1 Flash.

## ✨ Features

- **Voice Assistant**: Always-listening wake word ("Hello Assistant") and voice-commanded actions.
- **Scene Description**: Real-time object and environment analysis using Gemini Vision.
- **OCR Signboard Reading**: Reads documents, street signs, and labels via camera.
- **Night Vision**: Enhances low-light environments for the AI to analyze more effectively.
- **Emergency SOS**: Voice-activated emergency alerting with simulated location sharing.
- **Continuous Mode**: Can be set to describe surroundings every few seconds for hands-free navigation.

## 🚀 Getting Started (Web App)

1. **Start the App**: Tap the "START" button on the landing page.
2. **Commands**:
   - "Hello Assistant" -> Wake word.
   - "What is in front of me?" -> Standard analysis.
   - "Read this for me" -> OCR mode.
   - "Continuous detection" -> Every 7 seconds updates.
   - "Emergency help" -> SOS mode.
   - "Night vision" -> Low light boost.

## 🛠 Tech Stack

- **Frontend**: React 18, Vite, Tailwind CSS, Lucide Icons, Motion.
- **AI Core**: Gemini 3.1 Flash (Google Generative AI).
- **Voice Engine**: Web Speech API (Native Browser Support).

---

## 🐍 Python Implementation (Reference)

For users who want to run a local version using YOLOv8 and traditional Python libraries, refer to the `python_implementation/` folder.

### Installation
```bash
cd python_implementation
pip install -r requirements.txt
python app.py
```

*Note: The local Python version requires local hardware access (Mic/Cam) and might require additional system drivers like PortAudio for `pyaudio` and Espeak for `pyttsx3`.*
