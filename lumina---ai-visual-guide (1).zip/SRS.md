# Software Requirements Specification (SRS)
## Project Title: AI-Powered Smart Assistant for Visually Impaired Navigation (Lumina)

**IEEE Standard Format**

---

### 1. Title Page
- **Project Title:** AI-Powered Smart Assistant for Visually Impaired Navigation (Lumina)
- **Domain:** AI for Social Impact / Assistive Technology
- **Academic Year:** 2025-2026
- **Status:** Development Prototype (Phase 1)

---

### 2. Abstract
Visually impaired individuals face significant challenges in navigating unfamiliar environments safely. Traditional aids like white canes provide limited information about the surroundings. "Lumina" is an AI-powered smart assistant that bridges this gap using Computer Vision and Voice Interaction. By leveraging Large Language Models (LLMs) like Gemini 3.1 Flash for scene description and OCR, and integrated voice engines for accessibility, the system provides real-time situational awareness. The system mimics a human guide by identifying obstacles, reading signs, and describing scenes, all controlled via hands-free voice commands.

---

### 3. Introduction

#### 3.1 Purpose
The purpose of this document is to define the functional and non-functional requirements for the Lumina Smart Assistant. It serves as a blueprint for developers, testers, and stakeholders to understand the system's capabilities in assisting blind users with navigation and object recognition.

#### 3.2 Scope
The scope includes a cross-platform web application (and a Python-based local reference) that utilizes a camera feed to analyze the environment. It covers:
- Real-time scene description.
- OCR for signboard and document reading.
- Emergency SOS alerting.
- Voice-controlled interface (Hands-free).
- Basic GPS navigation guidance.

#### 3.3 Objectives
- To provide a completely hands-free interface for blind users.
- To use state-of-the-art AI for accurate object and hazard detection.
- To provide localized support (English and Kannada).
- To ensure low-latency response times for safety.

#### 3.4 Problem Statement
Existing navigation aids for the blind (white canes, guide dogs) are either limited in range or expensive to maintain. Mobile apps often rely on complex touch gestures which are difficult for many visually impaired users to master. There is a need for a "Voice-First" AI system that can "see" and "speak" naturally to the user.

#### 3.5 Proposed System
Lumina suggests a multi-modal approach:
1. **Vision Layer:** Uses Gemini 3.1 Flash / YOLOv8 for detection.
2. **Interface Layer:** Web Speech API for listening and speaking.
3. **Emergency Layer:** GPS and alerting systems for safety.
Users interact solely with their voice, asking questions like "What is in front of me?" or "Read this board."

---

### 4. Domain Description
- **AI for Social Impact:** Using machine learning to solve critical human problems.
- **Assistive Technology:** Software/hardware designed to improve functional capabilities of people with disabilities.
- **Computer Vision:** The field of AI that enables computers to interpret and understand the visual world.

---

### 5. System Features

| Feature | Description |
| :--- | :--- |
| **Voice Command Center** | Always-on listener for wake-words like "Hello Assistant". |
| **Scene Analysis** | High-level description of the surroundings (e.g., "You are in a living room with a sofa"). |
| **OCR & Reading** | Extracts text from signboards, books, or medicine labels. |
| **Hazard Detection** | Identifies stairs, vehicles, and obstacles with "Low/High" danger levels. |
| **Color Identification** | Helps users identify clothing colors or object details. |
| **Night Vision** | Software-based brightness/contrast enhancement for low-light conditions. |
| **Emergency SOS** | Triggers location sharing via voice command "Emergency Help". |

---

### 6. Functional Requirements

#### 6.1 User Voice Interaction Module
- Shall listen for the wake phrase "Hello Assistant".
- Shall support multi-language synthesis (English/Kannada).
- Shall ignore ambient noise and focus on user intent.

#### 6.2 AI Vision Module (Detection & Scene)
- Shall process frames at a rate of 1 frame every 5-10 seconds (for LLM) or 30fps (for YOLO).
- Shall categorize objects with at least 85% accuracy.
- Shall provide relative positions (e.g., "on your left").

#### 6.3 Emergency & Navigation Module
- Shall retrieve current geolocation coordinates.
- Shall trigger a simulated SOS alert to pre-saved contacts.

---

### 7. Non-Functional Requirements
- **Accessibility:** 100% voice-operable.
- **Reliability:** The system must handle network drops gracefully (cached speech).
- **Performance:** Synthesis (TTS) latency under 500ms.
- **Usability:** High-contrast UI for those with partial sight.
- **Accuracy:** Safety alerts must have zero false negatives for major hazards.

---

### 8. Technical Specifications

#### 8.1 Software Requirements
- **Frontend Framework:** React 18 (Vite).
- **AI Backend:** Google Gemini API (Vertex AI / AI Studio).
- **Styling:** Tailwind CSS (Modern Accessibility Standards).
- **Animations:** Motion for voice waveform visualization.
- **Speech Engine:** Web Speech API (Recognition & Synthesis).

#### 8.2 Hardware Requirements
- **Camera:** Minimum 720p resolution.
- **Microphone:** Noise-canceling array (standard on modern phones).
- **Speaker:** High-volume output or Bluetooth earphones.
- **Processor:** Modern smartphone SoC (Snapdragon 8 Gen 1+ or equivalent).

---

### 9. System Architecture

```mermaid
graph TD
    A[User Voice] --> B[Speech Recognition]
    B --> C[Command Parser]
    C --> D[Camera Frame Capture]
    D --> E[AI Analysis - Gemini/YOLO]
    E --> F[Response Generator]
    F --> G[Speech Synthesis]
    G --> H[User Audio]
    
    C --> I[Navigation/GPS API]
    C --> J[SOS Module]
```

---

### 10. Algorithm Explanation
1. **YOLOv8 (You Only Look Once):** Used for fast, local object detection. It divides images into a grid and predicts bounding boxes and probabilities.
2. **LLM Vision (Gemini):** Used for advanced semantic understanding and OCR. It converts images into high-dimensional embeddings to describe complex relationships (e.g., "A person is sitting on a bench reading a newspaper").
3. **HMM/Deep Learning (Speech):** The Web Speech API uses neural networks to map audio frequencies to text phonemes.

---

### 11. Advantages & Limitations

#### 11.1 Advantages
- Hands-free operation ensures safety while walking.
- Real-time hazard alerts prevent accidents.
- Low-cost alternative to expensive specialized hardware.

#### 11.2 Limitations
- Requires stable internet for high-quality LLM analysis.
- Battery intensive due to continuous camera usage.
- Lighting conditions can affect detection accuracy.

---

### 12. Conclusion
Lumina represents a significant step forward in assistive technology. By combining modern AI vision with a voice-first interface, it provides visually impaired individuals with a new level of independence. Future iterations will focus on edge-computing to remove internet dependency and integration with smart glasses.

---

### 13. References
- IEEE Standard for Software Requirements Specifications (IEEE Std 830-1998).
- Google Gemini API Documentation.
- Ultralytics YOLOv8 Documentation.
- Web Speech API Specification (W3C).
