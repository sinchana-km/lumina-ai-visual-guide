import cv2
import pyttsx3
import speech_recognition as sr
from ultralytics import YOLO
import threading
import time

# Initialize Voice
engine = pyttsx3.init()
def speak(text):
    print(f"Assistant: {text}")
    engine.say(text)
    engine.runAndWait()

# Load YOLOv8 Model
model = YOLO('yolov8n.pt')

class SmartAssistant:
    def __init__(self):
        self.running = True
        self.detecting = False
        self.camera = cv2.VideoCapture(0)

    def start_voice_assistant(self):
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening for 'Hello Assistant'...")
            while self.running:
                try:
                    audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
                    command = recognizer.recognize_google(audio).lower()
                    print(f"User: {command}")
                    self.handle_command(command)
                except Exception:
                    continue

    def handle_command(self, command):
        if "hello assistant" in command:
            speak("Hello! I am your smart assistant. How can I help you navigate today?")
        elif "start detection" in command:
            self.detecting = True
            speak("Starting object detection.")
        elif "stop detection" in command:
            self.detecting = False
            speak("Stopping detection.")
        elif "emergency" in command:
            speak("Emergency SOS initiated. Alerting contacts.")
        elif "describe" in command:
            self.describe_scene()
        elif "stop assistant" in command:
            self.running = False
            speak("Goodbye.")

    def describe_scene(self):
        ret, frame = self.camera.read()
        if ret:
            results = model(frame)
            objects = []
            for r in results:
                for c in r.boxes.cls:
                    objects.append(model.names[int(c)])
            
            if objects:
                unique_objs = set(objects)
                speak(f"I see {', '.join(unique_objs)} in front of you.")
            else:
                speak("The path ahead seems clear.")

    def detection_loop(self):
        while self.running:
            if self.detecting:
                ret, frame = self.camera.read()
                if ret:
                    results = model(frame)
                    # Process results and alert for obstacles
                    # (Simplified for demonstration)
                    for r in results:
                        for box in r.boxes:
                            cls = int(box.cls[0])
                            name = model.names[cls]
                            if name in ['person', 'car', 'chair']:
                                speak(f"{name} detected ahead.")
                                time.sleep(2) # Prevent spamming
            time.sleep(0.1)

if __name__ == "__main__":
    assistant = SmartAssistant()
    
    # Start threads
    voice_thread = threading.Thread(target=assistant.start_voice_assistant)
    detection_thread = threading.Thread(target=assistant.detection_loop)
    
    voice_thread.start()
    detection_thread.start()
    
    print("AI Smart Assistant Started. (Python Local Version)")
    
    # Keep main thread alive
    while assistant.running:
        time.sleep(1)
    
    assistant.camera.release()
